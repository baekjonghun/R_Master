import sys, io, time , os
from selenium import webdriver
from bs4 import BeautifulSoup
import urllib.request as dl
import re
import simplejson as json


sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')


drivers = webdriver.Chrome('C:\\bigdata\\chrome\\chromedriver')
drivers.get('http://korean.visitseoul.net/attractions?curPage=6')

html = drivers.page_source

with open('C:\\Users\\Administrator.Sc-201801171515\\Desktop\\seoul_sight\\html\\seoulList7_cr.html', 'w' , encoding='utf-8') as file:
    file.write(html)


f1 = open('C:\\Users\\Administrator.Sc-201801171515\\Desktop\\seoul_sight\\html\\seoulList7_cr.html', 'r', encoding='utf-8')
html = f1.read()
soup = BeautifulSoup(html, 'html.parser').find_all(class_='heading3')


temp = []
for i in soup:
    print(i.a.get_text())
    temp.append(i.a.get_text())


print(temp)


#
#
# with open('C:\\Users\\Administrator.Sc-201801171515\\Desktop\\seoul_sight\\seoul_sights_dic.txt', 'a' , encoding='utf-8') as file:
#     file.write(html)
